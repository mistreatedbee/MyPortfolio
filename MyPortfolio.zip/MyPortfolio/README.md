
## Getting Started

1. Run `npm install`
2. Run `npm run dev`
